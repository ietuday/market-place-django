from django.apps import AppConfig


class SixerrappConfig(AppConfig):
    name = 'sixerrapp'
